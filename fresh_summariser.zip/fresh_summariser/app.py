from flask import Flask, render_template, request, redirect, url_for
from werkzeug.utils import secure_filename
import os
import fitz  # PyMuPDF
from transformers import T5ForConditionalGeneration, T5Tokenizer

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads/'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB max-upload limit
ALLOWED_EXTENSIONS = {'txt', 'pdf'}

model_path = '/home/hector/Documents/Projects/models/t5-small_model'
tokeniser_path = '/home/hector/Documents/Projects/models/t5-small_tokeniser'

model = T5ForConditionalGeneration.from_pretrained(model_path)
tokenizer = T5Tokenizer.from_pretrained(tokeniser_path)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def extract_text_from_pdf(pdf_path):
    text = ""
    with fitz.open(pdf_path) as doc:
        for page in doc:
            text += page.get_text()
    return text

def summarize_text(text, min_len=40, max_len=150):
    inputs = tokenizer.encode("summarize: " + text, return_tensors="pt", max_length=512, truncation=True)
    summary_ids = model.generate(inputs, max_length=max_len, min_length=min_len, length_penalty=2.0, num_beams=4, early_stopping=True)
    summary = tokenizer.decode(summary_ids[0], skip_special_tokens=True)
    return summary

def estimate_reading_time(text):
    words_per_minute = 200  # Average reading speed
    word_count = len(text.split())
    return max(1, round(word_count / words_per_minute))

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '' or not allowed_file(file.filename):
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)

            if filename.endswith('.pdf'):
                text = extract_text_from_pdf(file_path)
            else:  # Assuming it's a .txt file
                with open(file_path, 'r', encoding='utf-8') as f:
                    text = f.read()

            os.remove(file_path)  # Clean up the uploaded file
            summary = summarize_text(text)
            original_reading_time = estimate_reading_time(text)
            summary_reading_time = estimate_reading_time(summary)

            return render_template('results.html', original_text=text, summary=summary,
                                   original_reading_time=original_reading_time,
                                   summary_reading_time=summary_reading_time)
    return render_template('index.html')

@app.route('/upload_text', methods=['POST'])
def upload_text():
    text = request.form['nlp_text']
    min_len = request.form.get('min_summary_length', type=int) or 40
    max_len = request.form.get('max_summary_length', type=int) or 150

    summary = summarize_text(text, min_len, max_len)
    original_reading_time = estimate_reading_time(text)
    summary_reading_time = estimate_reading_time(summary)

    return render_template('results.html', original_text=text, summary=summary,
                           original_reading_time=original_reading_time,
                           summary_reading_time=summary_reading_time)

if __name__ == '__main__':
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])
    app.run(debug=True)

